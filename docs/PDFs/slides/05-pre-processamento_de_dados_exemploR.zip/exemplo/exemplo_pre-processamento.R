################################################################################
#                 Exemplo de Pipeline de Pré-Processamento                     #
################################################################################

# -----
# Objetivo:
# Aplicar as 6 etapas do pré-processamento de dados para transformar 4 arquivos
# "caóticos" (com inconsistências, ruído, erros de integração e `NA`s) em um
# único dataset limpo e agregado por município, pronto para modelagem.


# -----
# Pacotes
library(tidyverse)


# -----
# Carragando os Dados
setwd("/home/sadraque/Documentos/UFS/Disciplinas/2025.2/mineracao de dados em estatistica/slides/05-pre-processamento_de_dados/exemplo_simulado/")
sinan_sujo <- read_csv("sinan_dengue_sujo.csv")
sih_sujo <- read_csv("sih_internacoes_sujo.csv")
cadunico_sujo <- read_csv("cadunico_simulado_sujo.csv")
ibge_municipios <- read_csv("ibge_municipios_limpo.csv")


# -----
# Diagnóstico e Limpeza dos Dados do SINAN (Sistema de Informação de Agravos
# de Notificação)

# Sempre devemos olhar para os seus dados antes de limpá-los. Use `glimpse()`,
# `summary()`, `count()`, `hist()` ou `geom_boxplot()` para encontrar os problemas.

glimpse(sinan_sujo)
summary(sinan_sujo)
sinan_sujo |> count(NOME_MUNICIPIO)

# Vemos que temos 150 paciente (linhas). O summary indica que há idades fora do
# comum (máximo = 200) e um código de raça/cor igual a 99.
# Vamos pedir um boxplot de `IDADE_ANOS` para ver a distribuição das idades e a
# contagem das categorias de `RACA_COR_COD`.
sinan_sujo |> select(IDADE_ANOS) |> boxplot()
sinan_sujo |> count(RACA_COR_COD)

# O boxplot de idade indica que há uma idade fora do padrão (igual a 200 anos).
# A tabela da variável `RACA_COR_COD` mostra que o código 99 aparece 13 vezes.
# Ele é utilizado quando essa variável não foi informada.

# Vamos fazer a limpeza. Idades maiores que 120 anos e serão transformadas em
# `NA` e código raça/cor igual a 99 também.

sinan_limpo_passo_1 <- sinan_sujo |>
  mutate(
    # Use if_else() para transformar idades > 120 em NA
    IDADE_ANOS = if_else(..., ..., ...),
    
    # Use na_if() para converter 99 em NA
    RACA_COR_COD = na_if(..., ...)
  )

# Juntar com ibge_municipios
sinan_limpo_passo_2 <- sinan_limpo_passo_1 |>
  left_join(
    ..., # dataset da direita
    by = c("COD_MUN_DATASUS" = "...") # quais colunas usar para o join?
  )

# Verifique se funcionou
glimpse(sinan_limpo_passo_2)


# -----
# Diagnóstico e Limpeza dos Dados do  SIH/SUS (Sistema de Informações
# Hospitalares do SUS)

summary(sih_sujo)

# Há um valor negativo para `VL_TOTAL_INTERNACAO`. O valor da internação não
# pode ser negativo. Vamos transformar em `NA`.
sih_limpo <- sih_sujo |>
  mutate(
    # Transforme em NA valores de internação negativos
    VL_TOTAL_INTERNACAO = if_else(..., ..., ...)
  ) |>
  # Juntar com ibge_municipios
  left_join(
    ...,
    by = c("..." = "...")
  )

glimpse(sih_limpo)


# -----
# Diagnóstico e Limpeza dos Dados do CadÚnico

summary(cadunico_sujo)
cadunico_sujo |> count(SEXO_CHAR)

# Note que SEXO_CHAR precisa ser padronizado.
# RENDA_PER_CAPITA possui valor negativo (o que não faz sentido).
# RENDA_TOTAL_FAM e redundante se já temos a renda per capita. Vamos remover.
cadunico_limpo <- cadunico_sujo |>
  mutate(
    # Usando case_when() para padronizar o sexo
    SEXO_PADRAO = case_when(
      SEXO_CHAR %in% c("M", "Masculino") ~ "M",
      SEXO_CHAR %in% c("F", "Feminino") ~ "F",
      TRUE ~ NA_character_ # O resto vira NA
    ),
    
    # Converter valores negativos em NA
    RENDA_PER_CAPITA = ifelse(..., ..., ...)
  ) |>
  # Remover a coluna redundante
  select(-RENDA_TOTAL_FAM)

# Nota: O COD_MUN_IBGE_7D já está aqui, não precisamos fazer join!

glimpse(cadunico_limpo)


# -----
# Agregação dos dados para que fiquem em nível municipal.
# As bases estão em níveis diferentes (paciente, internação, pessoa). Para criar
# um dataset analítico, precisamos agregá-los por município (COD_IBGE_7D).

# Agregando SINAN
# Vamos contar o número de casos de dengue e a idade média por município.
sinan_agregado <- sinan_limpo_passo_2 |>
  group_by(COD_IBGE_7D, NOME_MUNICIPIO_PADRAO) |>
  summarize(
    N_CASOS_DENGUE = n(),
    IDADE_MEDIA_DENGUE = mean(IDADE_ANOS, na.rm = TRUE)
  )

glimpse(sinan_agregado)


# Agregando SIH
# Vamos calcular o valor médio das internações e o número total de internações.
sih_agregado <- sih_limpo |>
  # Complete o group_by() e summarize()
  group_by(...) |>
  summarize(
    N_INTERNACOES = ...,
    VL_MEDIO_INTERNACAO = mean(..., na.rm = TRUE)
  )

glimpse(sih_agregado)


# Agregando CadÚnico
# Vamos calcular a renda média per capita e o % de escolaridade superior.
cadunico_agregado <- cadunico_limpo |>
  group_by(COD_MUN_IBGE_7D) |>
  summarize(
    RENDA_MEDIA_MUN = mean(RENDA_PER_CAPITA, na.rm = TRUE),
    
    # Calcular o % de pessoas com "Superior"
    PCT_SUPERIOR = mean(ESCOLARIDADE == "...", na.rm = TRUE)
  )

glimpse(cadunico_agregado)


# -----
# Agora, vamos juntar os 3 datasets agregados em um só!

# Vamos usar o ibge_municipios como base (para não perder nenhum município)
dataset_analitico <- ibge_municipios |>
  
  # Juntar dados do SINAN
  left_join(sinan_agregado, by = "COD_IBGE_7D") |>
  
  # Juntar dados do SIH
  left_join(..., by = "...") |>
  
  # Juntar dados do CadÚnico
  left_join(..., by = c("COD_IBGE_7D" = "..."))


# Resultado final
glimpse(dataset_analitico)