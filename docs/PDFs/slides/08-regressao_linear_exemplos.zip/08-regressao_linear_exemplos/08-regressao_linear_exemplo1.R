#----------------------------------------------------------------
# Predição de Salários com Regressão Linear
#----------------------------------------------------------------

# Pacotes essenciais
library(tidyverse)
library(tidymodels) # Framework moderno de ML
library(Sleuth3)    # Dados

# Os dados são sobre funcionários de uma categoria profissional
# (escriturário qualificado de nível inicial) de um banco que
# foi processado por discriminação sexual. Os dados referem-se
# a 32 funcionários do sexo masculino e 61 do sexo feminino,
# contratados entre 1965 e 1975.

# A variável resposta é Bsal, o salário anual no momento da contratação

# -----

# 1. Carregamento e Preparação
salarios <- Sleuth3::case1202 |> 
  janitor::clean_names() # a função clean_names() do pacote janitor
                         # padroniza os nomes das variáveis

glimpse(salarios)

# -----

# 2. Dividindo os dados em Treino e Teste
set.seed(123) # Para reprodutibilidade

# Divisão 75% Treino / 25% Teste
# strata = bsal garante que a distribuição de salários seja igual nos
# conjuntos de dados gerados
salarios_split <- initial_split(salarios, prop = 0.75, strata = bsal)
salarios_treino <- training(salarios_split)
salarios_teste  <- testing(salarios_split)

# -----

# 3. Treinamento do Modelo (Apenas nos dados de TREINO)
# Modelo completo sem variáveis de identificação desnecessárias
modelo_salario <- lm(bsal ~ sal77 + sex + senior + age + educ + exper, 
                     data = salarios_treino)

# Nota: Não olhamos p-valor aqui. O foco é performance.

# -----

# 4. Predição (A Hora da Verdade nos dados de TESTE)
predicoes <- predict(modelo_salario, newdata = salarios_teste)

# Unindo Real vs Previsto
resultados_salario <- salarios_teste |> 
  select(bsal) |> 
  mutate(.pred = predicoes)

# -----

# 5. Avaliação de Performance (Métricas de Erro)
metricas <- resultados_salario |> 
  metrics(truth = bsal, estimate = .pred)
metricas
# RMSE: Erro médio em dólares.
# Rsq: Capacidade explicativa nos dados novos.
# Essas métricas são usadas para comparar modelos. Quanto menor, melhor.

# -----

# 6. Visualizando o Erro
ggplot(resultados_salario, aes(x = bsal, y = .pred)) +
  geom_point(color = "#27276d", alpha = 0.7, size = 3) +
  geom_abline(color = "red", linetype = "dashed") + # Linha perfeita
  labs(
    title = "Predição de Salários: Real vs Previsto",
    x = "Salário Real ($)",
    y = "Salário Previsto ($)"
  ) +
  theme_minimal()
