#----------------------------------------------------------------
# Predição com Variável Resposta Transformada (Imóveis)
#----------------------------------------------------------------

library(tidyverse)
library(tidymodels)
library(olsrr)

# -----

# 1. Importando os dados
bd <- read_table("/home/sadraque/Documentos/UFS/Disciplinas/2025.2/mineracao de dados em estatistica/slides/08-regressao_linear/exemplos/dados.txt")


# Antes de prosseguir, vamos olhar para a nossa variável alvo (Y): Preço.

# Gráfico 1: Preço Original
p1 <- ggplot(dados_imoveis, aes(x = preco)) +
  geom_histogram(fill = "firebrick", bins = 30) +
  labs(title = "Escala Original: Assimétrica", x = "Preço ($)")

# Gráfico 2: Preço com Log
p2 <- ggplot(dados_imoveis, aes(x = log(preco))) +
  geom_histogram(fill = "steelblue", bins = 30) +
  labs(title = "Escala Log: Mais Simétrica", x = "Log(Preço)")

library(patchwork)
p1 + p2

# Preços de imóveis geralmente têm "cauda longa" à direita. 
# Poucas casas muito caras "esticam" o modelo linear, fazendo ele errar 
# muito nas casas baratas (heterocedasticidade).

# O Logaritmo "aperta" os valores grandes e "estica" os pequenos.
# Isso torna a distribuição mais parecida com uma Normal (sino).

# A Regressão Linear funciona MUITO melhor com dados simétricos.
# Por isso vamos usar os dados transformados com Log

# -----

dados_imoveis <- bd |>
  mutate(
    preco = price,
    tam_lote = 0.09 * lotsize,
    lpreco = log(price),       # Variável resposta transformada (Log)
    ltam_lote = log(tam_lote), # variável explicativa transformada
    # Recodificação simplificada
    garagem = factor(ifelse(driveway == "yes", "Sim", "Não")),
    ar_central = factor(ifelse(airco == "yes", "Sim", "Não")),
    bairro_pref = factor(ifelse(prefarea == "yes", "Sim", "Não")),
    # Criando dummies para agrupar o numero de quartos
    quartos_cat = case_when(
      bedrooms <= 2 ~ "Ate_2",
      bedrooms == 3 ~ "Tres",
      bedrooms >= 4 ~ "Quatro_Mais"
    ) |> factor(),
    banheiros_cat = case_when(
      bathrms == 1 ~ "Um",
      bathrms >= 2 ~ "Dois_Mais"
    ) |> factor()
  ) |> 
  select(preco, lpreco, ltam_lote, garagem, ar_central, bairro_pref, quartos_cat, banheiros_cat)

# Ficamos com as seguintes variáveis
# - preco: preço de venda da casa
# - tam_lote: tamanho do lote do imóvel
# - quartos: número de quartos
# - banheiros: número de banheiros
# - pavimentos: número de pavimentos, excluindo o porão
# - garagem: há entrada para carros
# - quarto_recreacao: há um quarto de recreação
# - porao: há um porão totalmente construído
# - aquec_gas_agua: uso de gás para aquecimento de água
# - há ar-condicionado central
# - n_vagas_garagem: número de vagas na garagem
# - bairro_preferido: é localizada no bairro preferido da cidade


# -----

# 2. Divisão (Treino/Teste)
set.seed(999)
imoveis_split <- initial_split(dados_imoveis, prop = 0.80, strata = lpreco)
imoveis_treino <- training(imoveis_split)
imoveis_teste  <- testing(imoveis_split)

# -----

# 3. Ajuste do Modelo (Usando as variáveis transformadas e dummies)
# Treinamos para prever o LOG do preço (lpreco)
modelo_casas <- lm(lpreco ~ ltam_lote + quartos_cat + banheiros_cat + 
                     garagem + ar_central + bairro_pref, 
                   data = imoveis_treino)

# -----

# 4. Predição e REVERSÃO (Back-transformation)
# Passo crucial: O modelo prevê log(preco). Precisamos de exp() para ver R$.

predicoes_log <- predict(modelo_casas, newdata = imoveis_teste)

resultados_casas <- imoveis_teste |> 
  select(preco) |>  # Selecionamos o PREÇO REAL (não o log)
  mutate(
    .pred_log = predicoes_log,
    .pred_real = exp(predicoes_log) # Revertendo log para R$
  )

# -----

# 5. Avaliação
# Calculamos o erro na moeda corrente (R$), que é o que importa para o negócio
metricas_casas <- resultados_casas |> 
  metrics(truth = preco, estimate = .pred_real)
metricas_casas

# -----

# 6. Visualização do Erro (Escala Real)
ggplot(resultados_casas, aes(x = preco, y = .pred_real)) +
  geom_point(color = "#0a6921", alpha = 0.6, size = 2.5) +
  geom_abline(color = "red", linetype = "dashed") +
  scale_x_continuous(labels = scales::dollar) +
  scale_y_continuous(labels = scales::dollar) +
  labs(
    title = "Predição de Preço de Imóveis",
    x = "Preço Real",
    y = "Preço Previsto (Revertido de Log)"
  ) +
  theme_minimal()
