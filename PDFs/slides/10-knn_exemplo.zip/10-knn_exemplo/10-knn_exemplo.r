rm(list=ls()) # remove o que tiver na memória

# ----------------------------------------------------
# k-NN para Classificação
# ----------------------------------------------------

## Pacotes
library(tidyverse)
library(caret)
library(recipes)
library(janitor)
library(DataExplorer)
library(fastDummies)

## Importando os dados
# Conjunto de dados sobre doença cardíaca
dados <- read_csv("/home/sadraque/Documentos/UFS/Disciplinas/2025.2/mineracao de dados em estatistica/slides/10-knn/10-knn_exemplo/heart.csv", col_types = "nffnnffnfnfnff")
glimpse(dados)

# Limpeza inicial
dados <- dados |>
  janitor::clean_names() |>  # Limpa e padroniza os nomes das colunas
  janitor::remove_empty(which = c("rows","cols")) # remove todas as linhas e colunas completamente vazias

DataExplorer::plot_missing(dados)
glimpse(dados)

# Remover colunas com mais de 10% de NAs
dados2 <- dados |>
  select(-c(s_tslope, defect_type, colored_vessels))

# Remover linhas com NAs
completo <- complete.cases(dados2)
dados3 <- dados2[completo,]
DataExplorer::plot_missing(dados3)
glimpse(dados3)

# Certificar que resposta é fator
dados3 <- dados3 |> mutate(heart_disease = as.factor(heart_disease))


# ----- Partição (75% / 25%) - antes do pré-processamento -----
set.seed(1234)
indices <- createDataPartition(dados3$heart_disease, p = 0.75, list = FALSE)
treino <- dados3[indices, ]
teste  <- dados3[-indices, ]


# ----- Recipe: criar dummies e normalizar numericas -----
# Selecionar preditores automaticamente: todas menos outcome (variável resposta)
rec_knn <- recipe(heart_disease ~ ., data = treino) |>
  # transformar strings em fatores, se houver
  step_string2factor(all_nominal_predictors()) |>
  # criar dummies one-hot para variáveis categóricas
  step_dummy(all_nominal_predictors(), one_hot = TRUE) |>
  # remover colunas com variância zero
  step_zv(all_predictors()) |>
  # normalização z-score (média 0, desvio 1)
  step_normalize(all_numeric_predictors())

# Preparar a receita com dados de treino
rec_prep <- prep(rec_knn, training = treino, retain = TRUE)

# Aplicar (bake) para treino e teste
treino_baked <- bake(rec_prep, new_data = treino)
teste_baked  <- bake(rec_prep, new_data = teste)

# Verificar nomes e dimensões
glimpse(treino_baked)
glimpse(teste_baked)


# Para usar class::knn: separar X e y e garantir formatos
treino_x <- treino_baked |> select(-heart_disease)
treino_y <- treino_baked |> pull(heart_disease)

teste_x <- teste_baked |> select(-heart_disease)
teste_y <- teste_baked |> pull(heart_disease)

# Verificando desbalanceamento no treino
janitor::tabyl(treino_y) |> janitor::adorn_pct_formatting()

# *****
# Modelo k-NN (classificação)
k_values <- seq(1, 51, by = 2)
acuracia <- vector("numeric", length(k_values))

for (i in seq_along(k_values)) {
  pred <- class::knn(train = treino_x,
                     test = teste_x,
                     cl = treino_y,
                     k = k_values[i])
  tabela_pred <- table(teste_y, pred)
  acuracia[i] <- sum(diag(tabela_pred)) / length(teste_y)
}

# Plot
ggplot(data = data.frame(k = k_values, acuracia = acuracia)) +
  geom_point(aes(x = k, y = acuracia), color = "orange", size = 3) +
  geom_line(aes(x = k, y = acuracia)) +
  geom_text(aes(x = k, y = acuracia, label = k), vjust = -0.8) +
  ylab("Acurácia") +
  ggtitle("Número de Vizinhos vs. Acurácia Preditiva") +
  theme_minimal()

# Melhor k (exemplo: selecionar max)
k_best <- k_values[which.max(acuracia)]
k_best

modknn <- class::knn(train = treino_x,
                     test = teste_x,
                     cl = treino_y,
                     k = k_best)

caret::confusionMatrix(modknn, teste_y, positive = "TRUE")

# Interpretando a saída
# Acurácia: taxa geral de acerto do modelo
# No Information Rate: acurácia se o modelo
#     prever sempre a classe mais frequente
# P-Value: avalia se o modelo é estatisticamente significante
#     melhor que prever sempre a classe majoritária
# Kappa: medida que leva em consideração a probabilidade
#     de concordância acidental. Quanto mais próximo de 1,
#     melhor.
# Sensitivity: taxa de verdadeiros positivos
# Especificidade: taxa de verdadeiros negativos

# *****
# Prevendo uma nova instância (xnovo) usando a mesma receita
xnovo <- data.frame(age = 60, sex = "female", pain_type = "Non-Anginal Pain",
                    resting_bp = 140, cholesterol = 313, high_blood_sugar = FALSE,
                    resting_ecg = "Normal", resting_hr = 133, exercise_angina = FALSE,
                    s_tdepression = .2, s_tslope = "Upsloping", colored_vessels = 0,
                    defect_type = "ReversibleDefect")

# OBSERVE: converter nomes/formatos iguais aos do treino
xnovo_baked <- bake(rec_prep, new_data = xnovo)

# Garantir a mesma ordem de colunas que treino_x
xnovo_baked <- xnovo_baked[, colnames(treino_x), drop = FALSE]

# Prever
class::knn(train = treino_x,
           test = xnovo_baked,
           cl = treino_y,
           k = k_best)





# -------------------------------------------------
# Regressão k-NN (Boston)
# -------------------------------------------------

# Modelagem do valor médio das casas

library(MASS)
boston <- MASS::Boston
glimpse(boston)

# limpeza nomes e NAs
boston <- boston |>
  janitor::clean_names() |>
  janitor::remove_empty(which = c("rows","cols"))

DataExplorer::plot_missing(boston)

# Converter variáveis que devem ser fator
boston <- boston |>
  mutate(chas = as.factor(chas),
         rad = as.factor(rad))

# Partição (85/15)
set.seed(123)
indices_boston <- createDataPartition(boston$medv, p = 0.85, list = FALSE)
treino_boston <- boston[indices_boston, ]
teste_boston  <- boston[-indices_boston, ]

# Recipe: dummies + z-score normalização (step_normalize)
rec_boston <- recipe(medv ~ ., data = treino_boston) |>
  step_dummy(all_nominal_predictors(), one_hot = TRUE) |>
  step_zv(all_predictors()) |>
  step_normalize(all_numeric_predictors())

rec_boston_prep <- prep(rec_boston, training = treino_boston, retain = TRUE)

treino_boston_baked <- bake(rec_boston_prep, new_data = treino_boston)
teste_boston_baked  <- bake(rec_boston_prep, new_data = teste_boston)

# Separar X e y
treino_boston_x <- treino_boston_baked |> select(-medv)
# ou
# treino_boston_x <- treino_boston_baked[-12]
treino_boston_y <- treino_boston_baked |> pull(medv)

teste_boston_x <- teste_boston_baked |> select(-medv)
# ou
# teste_boston_x <- teste_boston_baked[-12]
teste_boston_y <- teste_boston_baked |> pull(medv)

# *****
# Modelo k-NN regressão (testando k 1:50)
# testando diferentes valores de k pelo RMSE
k <- 1:50
RMSE <- vector()
for (i in 1:length(k)) {
  mod_knnreg <- knnreg(x = treino_boston_x,
                       y = treino_boston_y,
                       k = k[i])
  pred <- predict(mod_knnreg, teste_boston_x)
  RMSE[i] <- caret::RMSE(teste_boston_y, pred)
}

# Plot
ggplot(data = data.frame(k,RMSE)) +
  geom_point(mapping = aes(x = k, y = RMSE),
             color = "orange", size = 3) +
  geom_line(mapping = aes(x = k, y = RMSE)) +
  geom_text(mapping = aes(x = k, y = RMSE, label = k), vjust = -0.8) +  # Adiciona os valores de k acima dos pontos
  ylab("RMSE") +
  ggtitle("Número de Vizinhos vs. RMSE") +
  theme_minimal()

# Melhor k
k_best_boston <- k[which.min(RMSE)]
k_best_boston

# Ajuste final e métricas
modeloknn <- caret::knnreg(x = treino_boston_x, y = treino_boston_y, k = k_best_boston)
pred_y <- predict(modeloknn, newdata = teste_boston_x)

mse <- mean((teste_boston_y - pred_y)^2)
mae <- caret::MAE(teste_boston_y, pred_y)
rmse <- caret::RMSE(teste_boston_y, pred_y)
cat("MSE: ", mse, " MAE: ", mae, " RMSE: ", rmse, "\n")

# Gráfico real vs previsto
df <- data.frame(x = seq_along(teste_boston_y), original = teste_boston_y, predicted = pred_y)
ggplot(df, aes(x = x)) +
  geom_line(aes(y = original, color = "original-medv"), size = 1) +
  geom_line(aes(y = predicted, color = "predicted-medv"), size = 1) +
  labs(title = "Predição de valor de imóveis em Boston") +
  theme_minimal()

