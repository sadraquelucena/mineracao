rm(list=ls()) # remove o que tiver na memória

# ----------------------------------------------------
# Conjunto Letter Recognition
# Objetivo: Identificar as letras em imagens escaneadas
# Variável objetivo: lettr
# Fonte dos dados: https://archive.ics.uci.edu/dataset/59/letter+recognition
# ----------------------------------------------------

# Pacotes
library(tidyverse)
library(caret) # para cross-validation
library(randomForest) # Random Forest
library(C50) # C5.0
library(xgboost)# XGBoost

# ----------------------------------------------------
# Importando os dados
# Textos contendo as letras foram digitalizados, convertidos
# em pixels e depois cada letra foi separada e convertida 
# em 16 atributos estatísticos
letras <- read.csv2("/home/sadraque/Documentos/UFS/Disciplinas/2025.2/mineracao de dados em estatistica/slides/14-SVM/14-SVM_exemplo/letter-recognition.csv",
                   header = T,
                   sep = ",")

str(letras)

# Precisamos converter a variável alvo em fator para usar SVM
letras <- letras |>
  dplyr::mutate(lettr = as.factor(lettr))

str(letras)

# Os algoritmos de SVM precisam que todas os atributos sejam numéricos
# Como todos os valores são ineros, não precisamos converter em números


# *****
# Separando os dados em treino (80%) e teste (20%)
# A variável resposta é income
set.seed(12345)
indices <- caret::createDataPartition(letras$lettr, p = .8, list = F)
dados_treino <- letras[indices, ]
dados_teste <- letras[-indices, ]


# *****
# Modelo 1: SVM linear com pacote kernlab
svm_linear <- kernlab::ksvm(
  lettr ~ .,
  data   = dados_treino,
  kernel = "vanilladot"
)
svm_linear

# Matriz de confusão
pred_linear <- kernlab::predict(svm_linear, dados_teste[, -1])
caret::confusionMatrix(pred_linear, dados_teste$lettr)


# *****
# Modelo 2: SVM com kernel RBF (Gaussiano)

library(caret)

controle <- trainControl(
  method = "cv",
  number = 5
)

svm_caret <- train(
  lettr ~ .,
  data      = dados_treino,
  method    = "svmRadial", # opções: https://topepo.github.io/caret/train-models-by-tag.html
  trControl = controle,
  tuneLength = 5
)

svm_caret

# Matriz de confusão
pred_caret <- predict(svm_caret, dados_teste)
confusionMatrix(pred_caret, dados_teste$lettr) 
