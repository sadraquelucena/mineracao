###############################################################################
#                       Regras de Associação: Exemplo 2                       #
###############################################################################

# -----------------------------------------------------------------------------
# 1. PREPARAÇÃO DO AMBIENTE DE ANÁLISE
# -----------------------------------------------------------------------------
# Instalação de pacotes se necessário
library(arules)
library(arulesViz)
library(tidyverse)

# Carregando a base de dados transacional (Matriz Esparsa)
data("Groceries")

# -----------------------------------------------------------------------------
# 2. DIAGNÓSTICO INICIAL (Análise Exploratória)
# Objetivo: Entender a densidade da matriz e os "Best-Sellers"
# -----------------------------------------------------------------------------

# Esparsidade: Quão cheia é a matriz? (Muitos zeros é o normal em varejo)
# Uma densidade de 0.026 significa que apenas 2.6% das células matriz
# (itens x transações) possuem dados.
summary(Groceries) 

# whole milk: 2513 (de 9835 transações)
# O leite integral é o principal gerador de tráfego da loja, presente em 25,5%
# de todas as cestas de compras. Qualquer ruptura de estoque neste item coloca
# em risco 1/4 das vendas totais da loja.

# 169 columns (items)
# Foram monitorados o desempenho de vendas cruzadas entre 169 categorias de
# produtos ativos no período analisado.

# Mean: 4.409, Median: 3.000, 1st Qu: 2.000
# A cesta média contém apenas 4 a 5 itens, e 50% dos clientes levam 3 itens ou menos.
# O perfil predominante do cliente é de compra de reposição/conveniência, e não de abastecimento mensal.

# Visualizando os 10 itens mais frequentes (As "âncoras" da loja)
# Decisão de Negócio: Estes itens nunca devem faltar no estoque.
# 1. Frequência Relativa (Os mais vendidos em %)
itemFrequencyPlot(Groceries,
                  topN = 10,
                  type = "relative", # Mostra % em vez de contagem bruta
                  col = "#4682B4",   # Azul "Corporativo"
                  main = "Top 10 Produtos: Penetração nas Cestas de Compras",
                  ylab = "Frequência Relativa (%)",
                  xlab = "Produtos")

# 2. Histograma do Tamanho das Cestas (Perfil do Cliente)
# Extraindo o tamanho de cada transação
tamanho_cesta <- size(Groceries)

# Criando um tibble para plotar com ggplot2 (mais bonito que hist base)
tibble(tamanho = tamanho_cesta) |>
  ggplot(aes(x = tamanho)) +
  geom_histogram(binwidth = 1, fill = "firebrick", color = "white") +
  labs(title = "Distribuição do Tamanho das Cestas",
       subtitle = "A maioria dos clientes faz compras pequenas (Reposição)",
       x = "Qtd de Itens na Cesta",
       y = "Qtd de Transações") +
  theme_minimal() +
  xlim(0, 20) # Focando onde importa (cortando outliers extremos)

# -----------------------------------------------------------------------------
# 3. MINERAÇÃO DE REGRAS (ALGORITMO APRIORI)
# -----------------------------------------------------------------------------
# Definição de Hiperparâmetros Estratégicos:
# Suporte (0.001): Aceitamos regras que apareçam em pelo menos 0.1% das transações (produtos de cauda longa).
# Confiança (0.5): Queremos que, dado o antecedente, o consequente ocorra em 50% das vezes.
# Minlen (2): Ignora regras vazias ou de um único item.

regras <- apriori(Groceries, 
                  parameter = list(supp = 0.001, 
                                   conf = 0.5, 
                                   minlen = 2,
                                   target = "rules"))

# Total de regras encontradas:
length(regras)

# -----------------------------------------------------------------------------
# 4. FILTRAGEM E INTELIGÊNCIA DE NEGÓCIO
# -----------------------------------------------------------------------------
# Lift > 1: A presença de A aumenta a probabilidade de B (Associação Positiva).
# Lift < 1: A presença de A diminui a probabilidade de B (Substitutos ou Repulsão).

# Filtrando regras com alto impacto (Lift > 2)
# Ordenando pela confiança (certeza da regra)
regras_estrategicas <- regras |>
  subset(lift > 2) |>
  sort(by = "lift", decreasing = TRUE)

# -----------------------------------------------------------------------------
# 5. RELATÓRIO PARA A DIRETORIA (Formatado como Dataframe)
# -----------------------------------------------------------------------------

# Convertendo para DataFrame para apresentação legível
relatorio_final <- as(regras_estrategicas, "data.frame") |>
  as_tibble() |>
  head(10) |> # Top 10 regras
  mutate(
    # Traduzindo métricas para linguagem de negócio
    Interpretação = paste0("Quem compra ", str_extract(rules, "\\{.*?\\}"), 
                           " tem ", round(lift, 2), "x mais chance de levar ",
                           str_extract(rules, "=> \\{.*?\\}"))
  ) |>
  select(rules, support, confidence, lift, Interpretação)

# Exibindo o relatório no console de forma limpa
print(relatorio_final, width = Inf)

# Jogue no ChatGPT e veja a inerpretação dessa saída.

# -----------------------------------------------------------------------------
# 6. VISUALIZAÇÃO DE REDE (NETWORK GRAPH)
# Objetivo: Ver clusters de produtos que se vendem juntos
# -----------------------------------------------------------------------------
# Dica: Use engine="htmlwidget" para gráficos interativos no RStudio
plot(head(regras_estrategicas, 20), 
     method = "graph", 
     engine = "htmlwidget")

# -----------------------------------------------------------------------------
# 7. INSIGHT DE AÇÃO IMEDIATA (EXEMPLO)
# -----------------------------------------------------------------------------
# Identificando a melhor regra (pode ser feito com as demais)
melhor_regra <- relatorio_final[1, ]
cat(melhor_regra$Interpretação, "\n") 
