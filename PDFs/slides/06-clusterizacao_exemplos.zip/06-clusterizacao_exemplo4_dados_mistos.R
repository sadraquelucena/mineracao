#####################################################################
#            Clusterização de Dados Mistos: K-Prototype             #
#####################################################################

# Vamos usar dados de uma campanha de marketing de uma instituição bancária Portuguesa.
#
# Os dados estão disponíveis em:
# https://www.kaggle.com/datasets/henriqueyamahata/bank-marketing
#
# Vamos usar as variáveis:
# - Age (numeric)
# - Job : type of job (categorical: 'admin.', 'blue-collar', 'entrepreneur', 'housemaid', 'management', 'retired', 'self-employed', 'services', 'student', 'technician', 'unemployed', 'unknown')
# - Marital : marital status (categorical: 'divorced', 'married', 'single', 'unknown' ; note: 'divorced' means divorced or widowed)
# - Education (categorical: 'basic.4y', 'basic.6y', 'basic.9y', 'high.school', 'illiterate', 'professional.course', 'university.degree', 'unknown')
# - Default: has credit in default? (categorical: 'no', 'yes', 'unknown')
# - Housing: has housing loan? (categorical: 'no', 'yes', 'unknown')
# - Loan: has personal loan? (categorical: 'no', 'yes', 'unknown')


# Parte 1: Carregando Pacotes 
# -------------------------------------------------------------------
library(tidyverse)    # Ecossistema para manipulação de dados e gráficos (ggplot2, dplyr...)
library(tidymodels)   # Ecossistema para modelagem, incluindo o 'recipes'
library(clustMixType) # Para clusterização
library(purrr)        #


# Parte 2: Carregando os Dados 
# -------------------------------------------------------------------
dados_banco <- read.csv2("/home/sadraque/Documentos/UFS/Disciplinas/2025.2/mineracao de dados em estatistica/slides/06-agrupamento_de_dados_com_k-means_e_metodos_relacionados/06-agrupamento_de_dados_com_k-means_e_metodos_relacionados_exemplos/bank-additional-full.csv",
                        sep = ";", dec = ".")
glimpse(dados_banco)


# Parte 3: Pré-processamento de Dados
# -------------------------------------------------------------------

dados_cluster <- dados_banco |>
  # 1. Transforma 'pdays' em uma categoria clara
  mutate(
    foi_contatado_antes = if_else(pdays == 999, "nao_contatado", "contatado_antes")
  ) |>
  # 2. Seleciona as colunas que definem o PERFIL do cliente
  select(
    # Demográficas
    age, 
    job, 
    marital, 
    education,
    
    # Comportamento/Status
    default, 
    housing, 
    loan,
    foi_contatado_antes, # A nova variável que criamos
    
    # Histórico de Campanha
    campaign, # Quantas vezes foi contatado nesta campanha
    previous  # Quantas vezes foi contatado ANTES desta campanha
  )

glimpse(dados_cluster)


# Pré-processamento com `recipes`

# Precisamos converter variaveis 'char' em 'factor'
# e normalizar variáveis numéricas
receita_kproto <- recipe(~ ., data = dados_cluster) |>
  
  # Converte todas as colunas de texto (nominais) para 'factor'
  step_string2factor(all_nominal_predictors()) |>
  
  # Padroniza (média 0, desvio 1) todas as numéricas
  # Essencial para a parte 'K-Means' do K-Prototypes
  step_normalize(all_numeric_predictors())

# 3.2. Preparar e "Assar" (bake) a receita
receita_preparada <- prep(receita_kproto)
dados_padronizados <- bake(receita_preparada, new_data = NULL)

glimpse(dados_padronizados)
# Agora você verá <fct> para categóricos e <dbl> (padronizados) para numéricos

# Verificando se se há NAs e as variáveis estão com média 0 e variância 1
skimr::skim(dados_padronizados)


# Parte 4: K-Prototype - Encontrando k ótimo
# -------------------------------------------------------------------

# Rodando o Método do Cotovelo (WCSS Híbrida)
k_values <- 2:10
wcss_kproto <- map_dbl(k_values, ~ {
  
  # 'nstart = 5' roda 5x e pega o melhor resultado para evitar 
  # um "ótimo local" ruim.
  model <- kproto(
    x = dados_padronizados, 
    k = .x, 
    nstart = 5, 
    iter.max = 10,
    verbose = FALSE # Desliga as mensagens de progresso
  )
  
  model$tot.withinss # Soma dos quadrados intra-clusters (WCSS) Híbrida
})

# Gráfico do Cotovelo
data.frame(k = k_values, wcss = wcss_kproto) |>
  ggplot(aes(x = k, y = wcss)) +
  geom_line(size = 1) + 
  geom_point(size = 3) +
  geom_vline(xintercept = 4, linetype = "dashed") + # Exemplo: se k=4 for o cotovelo
  labs(title = "Método do Cotovelo para K-Prototypes",
       x = "Número de Clusters (k)",
       y = "WCSS Híbrida Total")

# O gráfico indica 7 clusters.


# Parte 5: K-Prototype - Aplicação do Método
# -------------------------------------------------------------------
# Modelagem
set.seed(123)
modelo_kp <- kproto(
  x = dados_padronizados, 
  k = 7, 
  nstart = 10
)

# Para facilitar a interpretação dos clusters, vamos ver os dados originais
dados_cluster_final <- dados_cluster |>
  mutate(Cluster = modelo_kp$cluster)

# Ver as médias das variáveis numéricas originais
dados_cluster_final |>
  group_by(Cluster) |>
  summarise(
    Media_Idade = mean(age),
    Media_Contatos_Campanha = mean(campaign),
    Media_Contatos_Anteriores = mean(previous),
    Contagem = n()
  )

# Ver as modas (categorias mais comuns) das variáveis categóricas
# (Exemplo para 'job' e 'marital')
dados_cluster_final |>
  group_by(Cluster, job) |>
  summarise(Contagem = n()) |>
  slice_max(order_by = Contagem, n = 1) # Pega a moda (top 1)

dados_cluster_final |>
  group_by(Cluster, marital) |>
  summarise(Contagem = n()) |>
  slice_max(order_by = Contagem, n = 1)

dados_cluster_final |>
  group_by(Cluster, education) |>
  summarise(Contagem = n()) |>
  slice_max(order_by = Contagem, n = 1)

dados_cluster_final |>
  group_by(Cluster, default) |>
  summarise(Contagem = n()) |>
  slice_max(order_by = Contagem, n = 1)

dados_cluster_final |>
  group_by(Cluster, housing) |>
  summarise(Contagem = n()) |>
  slice_max(order_by = Contagem, n = 1)

dados_cluster_final |>
  group_by(Cluster, loan) |>
  summarise(Contagem = n()) |>
  slice_max(order_by = Contagem, n = 1)

dados_cluster_final |>
  group_by(Cluster, foi_contatado_antes) |>
  summarise(Contagem = n()) |>
  slice_max(order_by = Contagem, n = 1)

# A interpretação dos clusters pode ser dada com auxílio do ChatGPT