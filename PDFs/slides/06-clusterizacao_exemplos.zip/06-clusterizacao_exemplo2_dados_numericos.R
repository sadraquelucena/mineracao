#####################################################################
#            Clusterização de Dados Numéricos: Caso 2               #
#####################################################################

# Vamos usar os dados de taxa de óbitos que usamos na aula passada.
# O arquivo é obitos_municipios2024.csv

# Parte 1: Carregando Pacotes 
# -------------------------------------------------------------------
library(tidyverse)  # Ecossistema para manipulação de dados e gráficos (ggplot2, dplyr...)
library(tidymodels) # Ecossistema para modelagem, incluindo o 'recipes'
library(factoextra) # Visualização de resultados de cluster (fviz_cluster, fviz_nbclust)
library(cluster)    # Algoritmos de cluster (pam, daisy)
library(NbClust)    # Para ajudar a determinar o número de clusters por vários métodos


# Parte 2: Carregando os Dados 
# -------------------------------------------------------------------
obitos <- read.csv2("/home/sadraque/Documentos/UFS/Disciplinas/2025.2/mineracao de dados em estatistica/slides/06-agrupamento_de_dados_com_k-means_e_metodos_relacionados/06-agrupamento_de_dados_com_k-means_e_metodos_relacionados_exemplos/obitos_municipios2024.csv",
                    sep = ";", dec = ",")
glimpse(obitos)


# Selecionando apenas as colunas de interesse para clusterização
obtidos_para_cluster <- obitos |>
  select(taxa_mort_neoplasias,
         taxa_mort_circulatorio,
         taxa_mort_respiratorio,
         taxa_mort_transporte)

glimpse(obtidos_para_cluster) # Confirmar se todas as variáveis são numéricas


# Parte 3: Pré-processamento de Dados
# -------------------------------------------------------------------

# Pré-processamento com `recipes`

# Vamos padronizar os dados para poder usar um método de clusterização
receita_pad <- recipe(data = obtidos_para_cluster, ~ .) |>
  # step_normalize padroniza (z-score: média=0, dp=1)
  step_normalize(all_numeric_predictors())

# Preparando e aplicando a receita
receita_preparada <- prep(receita_pad)
dados_padronizados <- bake(receita_preparada, new_data = NULL)

# Verificando se os dados estão com média 0 e variância 1
skim(dados_padronizados)


# Parte 4: Escolha do método de clusterização
# -------------------------------------------------------------------
# Boxplot dos dados
# Se observarmos muitos outliers extremos, temos um forte argumento para
# abandonar o K-Means e usar uma alternativa robusta, como o K-Medoids.
par(mfrow = c(2,2)) # dividir a área de plotagem em 4 quadrantes
dados_padronizados |> select(taxa_mort_neoplasias) |> boxplot()
dados_padronizados |> select(taxa_mort_circulatorio) |> boxplot()
dados_padronizados |> select(taxa_mort_respiratorio) |> boxplot()
dados_padronizados |> select(taxa_mort_transporte) |> boxplot()
par(mfrow = c(1,1))

# Como há muitos outliers, vamos usar K-MEDOIDS.


# Parte 5: K-medoids (PAM) - Encontrando o k ótimo
# -------------------------------------------------------------------

# Para k-medoids, o método da silhueta é mais indicado.

## 1. Método da Silhueta Média
# COMO LER: Procuramos o valor de 'k' que MAXIMIZA a silhueta média.
# É o método mais robusto e recomendado para K-Medoids.
set.seed(123)
fviz_nbclust(dados_padronizados, pam, method = "silhouette", k.max = 10) +
  labs(subtitle = "Método da Silhueta para K-Medoids (PAM)")
# Este método está indicando 2 clusters


## 2. Método do Cotovelo (WCSS / Dissimilaridade Interna)
# COMO LER: Procuramos o "cotovelo" (elbow), o ponto onde 
# adicionar mais um cluster não traz uma redução significativa 
# na dissimilaridade total interna (WCSS).
set.seed(123)
fviz_nbclust(dados_padronizados, pam, method = "wss", k.max = 10) +
  geom_vline(xintercept = 5, linetype = 2) + # Adicionando linha do resultado da Silhueta
  labs(subtitle = "Método do Cotovelo (WCSS) para K-Medoids (PAM)")
# Este método demora muito para esses dados


## 3. Método da Estatística Gap
# COMO LER: Procuramos o valor de 'k' que MAXIMIZA a Estatística Gap.
# Este método compara a WCSS dos seus dados com a WCSS de dados 
# aleatórios (a "distribuição nula").
# NOTA: Este método pode ser BEM LENTO.
set.seed(123)
fviz_nbclust(dados_padronizados, pam, method = "gap_stat", nboot = 100, k.max = 10) +
  labs(subtitle = "Método da Estatística Gap para K-Medoids (PAM)")

# Este método demora muito para esses dados


# Parte 6: K-medoids (PAM) - Aplicação do Método
# -------------------------------------------------------------------
# 5. Modelagem K-Medoids (PAM)
set.seed(123)
modelo_kmedoids <- pam(dados_padronizados, k = 2)

# Visualização dos clusters
fviz_cluster(modelo_kmedoids, data = data_pam_num,
             geom = "point",
             ellipse.type = "convex",
             ggtheme = theme_minimal()) +
  labs(title = "Clusters K-Medoids (PAM) - Taxas de Mortalidade")

# Interpretação (A GRANDE VANTAGEM)
# Os medoides são pontos reais!
medoide_indices <- modelo_kmedoids$id.med
prototipos_reais <- obtidos_para_cluster[medoide_indices, ]

# Protótipos Reais (Medoides)
prototipos_reais

# Interpretação dos clusters:
# Cluster 1 - Baixa mortalidade por doenças e alta mortalidade por transporte
# Cluster 2 - Altíssima mortalidade por doenças crônicas e baixa mortalidade por transporte