#####################################################################
#                Clusterização de Dados Categóricos                 #
#####################################################################

# Vamos usar um conjunto de dados com descrições de cogumelos.
# As variaǘeis que vamos usar estão descritas abaixo:

# ---------------- CHAPÉU ----------------
# cap-shape: formato do chapéu
#   b=sino, c=cônico, x=convexo, f=plano, k=com nódulo, s=afundado
# cap-surface: superfície do chapéu
#   f=fibrosa, g=estriada, y=escamosa, s=lisa
# cap-color: cor do chapéu
#   n=marrom, b=bege, c=canela, g=cinza, r=verde, p=rosa,
#   u=roxa, e=vermelha, w=branca, y=amarela

# ---------------- OUTROS ----------------
# bruises: machucado
#   t=sim, f=não
# odor: odor
#   a=amêndoa, l=anis, c=creosoto, y=peixe, f=fétido,
#   m=mofado, n=nenhum, p=pungente, s=picante

# ---------------- LAMELAS ----------------
# gill-attachment: ligação das lamelas
#   a=aderente, d=descendente, f=livre, n=entalhada
# gill-spacing: espaçamento das lamelas
#   c=próximas, w=aglomeradas, d=distantes
# gill-size: tamanho das lamelas
#   b=largas, n=estreitas
# gill-color: cor das lamelas
#   k=preta, n=marrom, b=bege, h=chocolate, g=cinza, r=verde,
#   o=laranja, p=rosa, u=roxa, e=vermelha, w=branca, y=amarela

# ---------------- ESTIPE (HASTE) ----------------
# stalk-shape: formato do estipe
#   e=alargando na base, t=afinando
# stalk-root: tipo de raiz
#   b=bulbosa, c=em clava, u=em taça, e=igual, z=rizomorfos,
#   r=enraizada, ?=ausente
# stalk-surface-above-ring: textura acima do anel
# stalk-surface-below-ring: textura abaixo do anel
#   f=fibrosa, y=escamosa, k=sedosa, s=lisa
# stalk-color-above-ring / below-ring: cor do estipe
#   n=marrom, b=bege, c=canela, g=cinza, o=laranja,
#   p=rosa, e=vermelha, w=branca, y=amarela

# ---------------- VÉU E ANEL ----------------
# veil-type: tipo de véu -> p=parcial, u=universal
# veil-color: cor do véu -> n=marrom, o=laranja, w=branca, y=amarela
# ring-number: número de anéis -> n=nenhum, o=um, t=dois
# ring-type: tipo de anel
#   c=teia, e=efêmero, f=alargado, l=grande,
#   n=nenhum, p=pendente, s=em bainha, z=em zona

# ---------------- OUTROS ATRIBUTOS ----------------
# spore-print-color: cor do esporo
#   k=preto, n=marrom, b=bege, h=chocolate, r=verde,
#   o=laranja, u=roxo, w=branco, y=amarelo
# population: tipo de população
#   a=abundante, c=agrupada, n=numerosa,
#   s=dispersa, v=em pequenos grupos, y=solitária
# habitat: ambiente
#   g=gramíneas, l=folhas, m=prados, p=trilhas,
#   u=urbano, w=lixo, d=floresta


# Parte 1: Carregando Pacotes 
# -------------------------------------------------------------------
library(tidyverse)  # Ecossistema para manipulação de dados e gráficos (ggplot2, dplyr...)
library(tidymodels) # Ecossistema para modelagem, incluindo o 'recipes'
library(klaR)       # Para K-Modes
library(purrr)      # Para o loop funcional


# Parte 2: Carregando os Dados 
# -------------------------------------------------------------------
cogumelos <- read.csv2("/home/sadraque/Documentos/UFS/Disciplinas/2025.2/mineracao de dados em estatistica/slides/06-agrupamento_de_dados_com_k-means_e_metodos_relacionados/06-agrupamento_de_dados_com_k-means_e_metodos_relacionados_exemplos/mushrooms.csv",
                    sep = ",")
glimpse(cogumelos)


# Vamos remover a coluna alvo 'class' (venenoso/comestível), 
# pois clusterização é não-supervisionada.
cogumelos_para_cluster <- cogumelos |> dplyr::select(-class)
glimpse(cogumelos_para_cluster)

# Todas as 22 variáveis são categóricas (chr). Vamos ter que usar K-Modes.


# Parte 3: Pré-processamento de Dados
# -------------------------------------------------------------------

# O K-Modes (klaR) espera fatores, não strings (chr).
# Vamos então converter as variáveis para o tipo factor usando recipes
receita_kmodes <- recipe(~ ., data = cogumelos_para_cluster) |>
  # step_string2factor converte todas as colunas de character para factor
  step_string2factor(all_nominal_predictors())

receita_preparada <- prep(receita_kmodes)
dados_kmodes <- bake(receita_preparada, new_data = NULL)
glimpse(dados_kmodes)


# Parte 4: K-modes - Encontrando o k ótimo
# -------------------------------------------------------------------
# A função que roda K-Modes (klaR) precisa que os dadso estejam em um dataframe.
# Vamos converter para data frame
dados_kmodes_df <- as.data.frame(dados_kmodes)

# Vamos usar o Método do Cotovelo Manual
# factoextra não suporta kmodes, então fazemos um loop manual
# para calcular a dissimilaridade interna (usando a Distância de Hamming)
set.seed(123)
valores_k <- 2:10
total_withindiff <- c()
for (k in valores_k) {
  cl <- kmodes(dados_kmodes_df, k)
  total_withindiff <- c(total_withindiff, sum(cl$withindiff))
}

plot(valores_k, total_withindiff, type = "b", 
     xlab = "Number of Clusters (k)", 
     ylab = "Total Within-Cluster Difference",
     main = "Elbow Method for K-Modes")


# Plotando o cotovelo
data.frame(k = valores_k, wcss = total_withindiff) %>%
  ggplot(aes(x = k, y = wcss)) +
  geom_line() + geom_point() +
  labs(title = "Método do Cotovelo para K-Modes",
       x = "Número de Clusters (k)",
       y = "Dissimilaridade Intra-cluster Total")

# O cotovelo indica k=7.


# Parte 5: K-Modes - Aplicação do Método
# -------------------------------------------------------------------


# Modelagem K-Modes
set.seed(123)
modelo_kmodes <- kmodes(data = dados_kmodes_df, modes = 7, iter.max = 20, weighted = FALSE)

# Interpretação
# O centro de cada cluster é o vetor das modas (categorias mais frequentes)
modelo_kmodes$modes

# Jogue a saída e o significado de cada valor das variáveis para o chatGPT interepretar